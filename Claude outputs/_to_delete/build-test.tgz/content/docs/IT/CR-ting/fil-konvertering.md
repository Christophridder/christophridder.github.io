---
Title: " Fil Konvertering"
Weight: 2
geometry: margin=1cm
fontsize: 11pt
---


For md --> pdf brug [pandoc]({{< relref "pandoc" >}})

### NBconvert: Jupyter filer til HTML, pdf, latex, markdown
Programmet **nbconvert** konverterer jupyterfiler til html og alt muligt andet. 
billederne ligger så i en undermappe . Kik evtl "nat/Integralregning.md" 
Den danner en index.md fil 
programmet kaldes med 

** jupyter nbconvert --to marktown mitnavn.ipynb**

Med VS Code: 
content/
  integralregning/
    index.md
    Integralregning_files/
      billede1.png
      billede2.png
  massedefekt/
    index.md
    massedefekt_files/
      ...
Fordele:

Billeder ligger ved siden af siden de hører til — let at overskue i VS Code's filstifinder
Billedlinks i .md virker uden at du retter noget
Hver notebook bliver sin egen selvstændige mappe

## Workflow:  

- jupyter nbconvert --to markdown minnotebook.ipynb
- Opret mappe i content/
- Kopier .md → omdøb til index.md
- Kopier _files/ mappen med ind

## pandoc lave pdffer fra md 
- pandoc fil.md -o fil.pdf
- pandoc fil.md -o fil.docx

nedenstående giver bedre æåø support
- pandoc fil.md -o fil.pdf --pdf-engine=xelatex

Pandoc kan **IKKE** lave gode pdffer fra docx filer! det kører via Latex 

## åbne pdffer med Skim
open -a Skim fil.pdf
## download youtube film. 
Erstat URL med youtube link. 
køres i terminal
yt-dlp --cookies-from-browser firefox -f "bv*+ba/b" --merge-output-format mp4 "URL"