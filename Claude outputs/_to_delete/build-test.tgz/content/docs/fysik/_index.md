---
title: "Fysik"
weight: 2
bookCollapseSection: true
---

## Fysik

| Niveau | Årsplan | Emner | Eksperimenter |
|---|---|---|---|
| **A** | [Årsplan Fysik A]({{< relref "/docs/fysik/A-niveau" >}}) | [Emner A]({{< relref "/docs/fysik/emner-a" >}}) | [Eksperimenter A]({{< relref "/docs/fysik/A-Eksp" >}}) |
| **B** | [Årsplan Fysik B]({{< relref "/docs/fysik/B-niveau" >}}) | [Emner B]({{< relref "/docs/fysik/emner-b" >}}) | [Eksperimenter B]({{< relref "/docs/fysik/B-Eksp" >}}) |
| **C** | [Årsplan Fysik C]({{< relref "/docs/fysik/C-niveau" >}}) | [Emner C]({{< relref "/docs/fysik/emner-c" >}}) | [Eksperimenter C]({{< relref "/docs/fysik/C-Eksp" >}}) |

[Formelsamling C–A]({{< relref "/docs/fysik/formelsamling" >}}) · [Præsentationer]({{< relref "/docs/fysik/slides" >}}) · [Faglige metoder]({{< relref "/docs/fysik/Metoder" >}})
