---
title: Eksperimenter B
bookCollapseSection: true
weight: 12
---

|Nr.|Eksperiment|Emne|
|---|---|---|
| 10 | [Phosphorsyre i cola]({{< relref "phosphorsyre-cola" >}})| Syre-base (B-niveau) |
| 11 | [Jernindhold i ståluld]({{< relref "staaluld" >}})| Redox (B-niveau) |
| 12 | [Salmiak]({{< relref "salmiak" >}})| Ionforbindelser (B-niveau) |
| 13 | [Mangans oxidationstal]({{< relref "mangans-oxidationstal" >}})| Redox, oxidationstal (B-niveau) |
| 14 | [Farvestof i rød sodavand]({{< relref "farvestof-sodavand" >}})| Spektrofotometri (B-niveau) |
